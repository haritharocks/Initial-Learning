#pragma once

#include "tiling.h"
#include "superkernels.h"

#define NUM_LAYERS (1)

// Input
std::vector<uint32_t> input_dim = ifm_dim_1;
access_pattern input_ddr_pattern = tiling({.buffer_dimension = input_dim, .tiling_dimension = input_dim, .offset = { 0, 0, 0, 0 }});

// final output
std::vector<uint32_t> output_dim = ofm_dim_1;
access_pattern output_ddr_pattern = tiling({.buffer_dimension = output_dim, .tiling_dimension = output_dim, .offset = { 0, 0, 0, 0 }});
#define IFM_DDR_MEM_SIZE (input_dim[0]*input_dim[1]*input_dim[2]*input_dim[3])
#define OFM_DDR_MEM_SIZE (output_dim[0]*output_dim[1]*output_dim[2]*output_dim[3])
std::vector<location_constraint> ifm_loc_1 = {address(0,0, 0)};
std::vector<location_constraint> ofm_loc_1 = {address(1,0, 294912)};

class single_layer_overlay : public graph{
public:
kernel compute_node;

shared_buffer<uint8_t> ofm;

single_layer_overlay(
std::vector<access_pattern> ofm_pattern[],
uint32_t ofmsv_size,
const std::vector<location_constraint>& ofm_loc,
uint32_t kernel_iter,
uint32_t ofm_repetition,
uint32_t in0_ping = 0x0,
uint32_t in0_pong = 0x0)
{
ofm = shared_buffer<uint8_t>::create({512*1024},1,1);
location<buffer>(ofm) = ofm_loc;
  printf("***********************Creating Kernel\n");

compute_node = kernel::create(add_simple);
location<buffer>(compute_node.in[0]) = {address(0,0,in0_ping), address(0,0,in0_pong)};
location<dma>(compute_node.in[0]) = dma_channel(aie_tile,0,0,0);
source(compute_node) = "superkernels.cpp";
initialization_function(compute_node) = "node_init";
repetition_count(compute_node) = kernel_iter;
runtime<ratio>(compute_node) = 0.8;
location<kernel>(compute_node) = tile(0,0);
location<buffer>(compute_node.out[0]) = {address(0,0,0x0), address(0,0, 0x4000)};
location<dma>(compute_node.out[0]) = dma_channel(aie_tile,0,0,0);
async_repetition(compute_node.out[0] ) = ofm_repetition;
location<stack>(compute_node) = {address(0,0,0xb5a0)};
connect(compute_node.out[0], ofm.in[0]); 
dimensions(compute_node.out[0]) = {ofmsv_size};
write_access(ofm.in[0]) = ofm_pattern[0];
location<dma>(ofm.in[0]) = dma_channel(memory_tile, 1, 0, 0);
}

void connect_layer(
shared_buffer<uint8_t>& ifm, 
std::vector<access_pattern> ifm_pattern[], 
uint32_t ifmsv_size){
connect(ifm.out[0], compute_node.in[0]);
dimensions(compute_node.in[0]) = {ifmsv_size};
read_access(ifm.out[0]) = ifm_pattern[0];
location<dma>(ifm.out[0]) = dma_channel(memory_tile, 1, 0, 0);
}
};

class FlexMLGraph : public graph{
public:
single_layer_overlay flexml_layers[NUM_LAYERS] = {
single_layer_overlay(ofm_pattern_1,ofmsv_size_1,ofm_loc_1,kernel_iter_1,ofm_repetition_1,0x8000,0xca60)
};
// DDR and shared buffer
external_buffer<uint8_t> ifm_ddr; shared_buffer<uint8_t> ifm_sb;
external_buffer<uint8_t> ofm_ddr;

FlexMLGraph(){
// Creating DDR and shared buffer
  printf("***********************Creating Buffers\n");

ifm_ddr = external_buffer<uint8_t>::create(input_dim , 0 , 1); 
ifm_sb = shared_buffer<uint8_t>::create(input_dim , 1 , 1);
ofm_ddr = external_buffer<uint8_t>::create(input_dim , 1 , 0);
  printf("***********************Running Connections\n");

location<dma>(ifm_sb.in[0]) = dma_channel(memory_tile, 0 , 0 , 0); 
connect(ifm_ddr.out[0],ifm_sb.in[0]); 
read_access(ifm_ddr.out[0]) = tiling({.buffer_dimension = input_dim, .tiling_dimension = input_dim, .offset = {0,0,0,0}}); 
write_access(ifm_sb.in[0]) = tiling({.buffer_dimension = input_dim, .tiling_dimension = input_dim, .offset = {0,0,0,0}}); 

location<dma>(flexml_layers[NUM_LAYERS-1].ofm.out[0]) = dma_channel(memory_tile, 0 , 0 , 0); 
connect(flexml_layers[NUM_LAYERS-1].ofm.out[0],ofm_ddr.in[0]); 
read_access(flexml_layers[NUM_LAYERS-1].ofm.out[0]) = tiling({.buffer_dimension = input_dim, .tiling_dimension = input_dim, .offset = {0,0,0,0}}); 
write_access(ofm_ddr.in[0]) = tiling({.buffer_dimension = input_dim, .tiling_dimension = input_dim, .offset = {0,0,0,0}}); 

location<buffer>(ifm_sb) = ifm_loc_1;
  printf("***********************Connecting IFM and kernel\n");

flexml_layers[0].connect_layer(ifm_sb, ifm_pattern_1, ifmsv_size_1);
}
};

