#include "superkernels.h"
#include "mllib_kernels.h"

void node_init() {
    tile::current().set_saturation(saturation_mode::truncate);
    tile::current().set_rounding(rounding_mode::conv_even);
}

void add_simple
(
adf::input_buffer_conf<DTYPE_IFM, BPCTYPE_IFM>  & __restrict ifm,
adf::output_buffer_conf<DTYPE_OFM, BPCTYPE_OFM> & __restrict ofm
){
      printf("***********************Inside Kernel\n");

    ofm.acquire();

    int8* pIFM = (int8 *)ifm.data();
    int8* pOFM = (int8 *)ofm.data();

    const unsigned SIZE_IFM_SV = 8192;
    printf("Size: %d", SIZE_IFM_SV);

    std::fill_n(pOFM, SIZE_IFM_SV, 0);

    for (unsigned i=0; i<SIZE_IFM_SV; ++i) {
        pOFM[i] = pIFM[i] + 1;
        printf("Data at %d = %d", i, pIFM[i] + 1);
    }

    ofm.release();
}

