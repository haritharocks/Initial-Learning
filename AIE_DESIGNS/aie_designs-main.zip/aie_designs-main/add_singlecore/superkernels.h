#pragma once
#include "mllib_const.h"
#include <adf.h>
using namespace adf;

#define DTYPE_IFM int8
#define DTYPE_OFM int8
#define BPCTYPE_IFM bpc_sync_1d
#define BPCTYPE_OFM bpc_async_1d
void add_simple
(
adf::input_buffer_conf<DTYPE_IFM, BPCTYPE_IFM>  & __restrict ifm,
adf::output_buffer_conf<DTYPE_OFM, BPCTYPE_OFM> & __restrict ofm
);
