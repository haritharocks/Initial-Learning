#include <adf.h>
using namespace adf;
//Layer1
std::vector<uint32_t> ifm_dim_1 = {8, 16, 8, 8};
std::vector<uint32_t> ifm_bound_1 = {8, 16, 8, 8};
std::vector<uint32_t> ifmsv_dim_1 = {8, 16, 8, 8};
uint32_t ifmsv_size_1 = 8192;
uint32_t kernel_iter_1 = 1;
std::vector<access_pattern> ifm_pattern_1[] = {
{
  tiling({.buffer_dimension = {8, 16, 8, 8}, .tiling_dimension = {8, 16, 8, 8}, .offset = {0, 0, 0, 0}, .tile_traversal = { }, .packet_port_id = -1, .repetition = 1, .phase = 0, .boundary_dimension = {8, 16, 8, 8}})
}};


std::vector<uint32_t> ofm_dim_1 = {8, 16, 8, 8};
std::vector<uint32_t> ofm_bound_1 = {8, 16, 8, 8};
std::vector<uint32_t> ofmsv_dim_1 = {8, 16, 8, 8};
uint32_t ofmsv_size_1 = 8192;
uint32_t ofm_repetition_1 = 1;
std::vector<access_pattern> ofm_pattern_1[] = {
{
  tiling({.buffer_dimension = {8, 16, 8, 8}, .tiling_dimension = {8, 16, 8, 8}, .offset = {0, 0, 0, 0}, .tile_traversal = { }, .packet_port_id = 0, .repetition = 1, .phase = 0, .boundary_dimension = {}}),
}};
