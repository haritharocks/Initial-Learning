#include "overlay.h"
#include <fstream>
#include <iomanip>

#ifdef __AIESIM__
#include "../aie_runtime_control.cpp"
#endif

#define IFM_FILE "data/ifm32.txt"
#define OFM_FILE "data/ofm32.txt"

FlexMLGraph compute_graph;

int main() {
  const int ofm_size = OFM_DDR_MEM_SIZE;
  const int ifm_size = IFM_DDR_MEM_SIZE;

  uint32_t *ofm_buf = (uint32_t *)GMIO::malloc(ofm_size * sizeof(uint8_t));
  uint32_t *ifm_buf = (uint32_t *)GMIO::malloc(ifm_size * sizeof(uint8_t));

  compute_graph.init();

  std::ifstream ifm_ifs;
  ifm_ifs.open(IFM_FILE);
  if (!ifm_ifs.good()) {
    std::cout << "Failed to open " << IFM_FILE << "\n";
    exit(1);
  }
  std::cout << "Opened file " << IFM_FILE << " for reading IFM!!" << std::endl;
  for (int i = 0; i < ifm_size / 4; i++)
    ifm_ifs >> std::hex >> ifm_buf[i];
  ifm_ifs.close();

  // Set DDR base addresses
  compute_graph.ifm_ddr.setAddress(ifm_buf);
  compute_graph.ofm_ddr.setAddress(ofm_buf);

  printf("Running Kernel\n");
  compute_graph.run(1);
  printf("Done running Kernel\n");

#ifdef __AIESIM__
  executeRuntimeControl();
#endif

  std::cout << "OFM Shim DMA transfer done, ready for file I/O!!" << std::endl;

  compute_graph.end();

  std::ofstream ofm_ofs;
  ofm_ofs.open(OFM_FILE, std::ofstream::out | std::ofstream::trunc);
  std::cout << "Opened file " << OFM_FILE << " for writing OFM!!" << std::endl;
  for (int i = 0; i < ofm_size / 4; i++) {
    ofm_ofs << std::hex << std::setw(8) << std::setfill('0')
            << (uint32_t)ofm_buf[i] << std::endl;
  }
  ofm_ofs.close();

  GMIO::free(ofm_buf);
  GMIO::free(ifm_buf);

  return 0;
}
