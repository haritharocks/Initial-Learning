#include "graph.h"
#include <fstream>

#ifdef __AIESIM__
#include "../aie_runtime_control.cpp"
#endif

TinyYoloLayer1 g;

int main()
{
    const int ifm_size = 128;
    
 

    const int ofm_size = 128; 
    
    g.init();
//1
    uint32_t* ifmData = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr1.setAddress(ifmData);
    std::ifstream ifm_ifs;
    ifm_ifs.open("data/ifm.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs >> std::hex >> ifmData[i];
    ifm_ifs.close();
   
    uint32_t* ifmData1 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr2.setAddress(ifmData1);
    std::ifstream ifm_ifs1;
    ifm_ifs1.open("data/ifm1.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs1 >> std::hex >> ifmData1[i];
    ifm_ifs1.close();
   
    
    uint32_t* ofmData = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr1.setAddress(ofmData);
	
	uint32_t* ofmData1 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr2.setAddress(ofmData1);
//2
uint32_t* ifmData2 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr3.setAddress(ifmData2);
    std::ifstream ifm_ifs2;
    ifm_ifs2.open("data/ifm.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs2 >> std::hex >> ifmData2[i];
    ifm_ifs2.close();
   
    uint32_t* ifmData3 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr4.setAddress(ifmData3);
    std::ifstream ifm_ifs3;
    ifm_ifs3.open("data/ifm1.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs3 >> std::hex >> ifmData3[i];
    ifm_ifs3.close();
   
    
    uint32_t* ofmData2 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr3.setAddress(ofmData2);
	
	uint32_t* ofmData3 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr4.setAddress(ofmData3);
	
//3
uint32_t* ifmData4 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr5.setAddress(ifmData4);
    std::ifstream ifm_ifs4;
    ifm_ifs4.open("data/ifm.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs4 >> std::hex >> ifmData4[i];
    ifm_ifs4.close();
   
    uint32_t* ifmData5 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr6.setAddress(ifmData5);
    std::ifstream ifm_ifs5;
    ifm_ifs5.open("data/ifm1.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs5 >> std::hex >> ifmData5[i];
    ifm_ifs5.close();
   
    
    uint32_t* ofmData4 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr5.setAddress(ofmData4);
	
	uint32_t* ofmData5 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr6.setAddress(ofmData5);
//4
/*
uint32_t* ifmData6 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr7.setAddress(ifmData6);
    std::ifstream ifm_ifs6;
    ifm_ifs6.open("data/ifm.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs6 >> std::hex >> ifmData6[i];
    ifm_ifs6.close();
   
    uint32_t* ifmData7 = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ifm_ddr8.setAddress(ifmData7);
    std::ifstream ifm_ifs7;
    ifm_ifs7.open("data/ifm1.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs7 >> std::hex >> ifmData7[i];
    ifm_ifs7.close();
   
    
    uint32_t* ofmData6 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr7.setAddress(ofmData6);
	
	uint32_t* ofmData7 = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ofm_ddr8.setAddress(ofmData7);	

*/

    g.run(1);
    
#ifdef __AIESIM__
    executeRuntimeControl();
#endif
    
    g.end();
    
#ifndef __X86SIM__
    system("mkdir aiesimulator_output/data");
    std::ofstream ofs;
    ofs.open("aiesimulator_output/data/output1.txt", std::ofstream::out | std::ofstream::trunc);
#else
    system("mkdir x86simulator_output/data");
    std::ofstream ofs;
    ofs.open("x86simulator_output/data/output1.txt", std::ofstream::out | std::ofstream::trunc);
#endif

#ifndef __X86SIM__
    std::ofstream ofs1;
    ofs1.open("aiesimulator_output/data/output2.txt", std::ofstream::out | std::ofstream::trunc);
#else
    std::ofstream ofs1;
    ofs1.open("x86simulator_output/data/output2.txt", std::ofstream::out | std::ofstream::trunc);
#endif
    
#ifndef __X86SIM__    
    std::ofstream ofs2;
    ofs2.open("aiesimulator_output/data/output3.txt", std::ofstream::out | std::ofstream::trunc);
#else
    std::ofstream ofs2;
    ofs2.open("x86simulator_output/data/output3.txt", std::ofstream::out | std::ofstream::trunc);
#endif
    
#ifndef __X86SIM__
    std::ofstream ofs3;
    ofs3.open("aiesimulator_output/data/output4.txt", std::ofstream::out | std::ofstream::trunc);
#else 
    std::ofstream ofs3;
    ofs3.open("x86simulator_output/data/output4.txt", std::ofstream::out | std::ofstream::trunc);
#endif

#ifndef __X86SIM__    
    std::ofstream ofs4;
    ofs4.open("aiesimulator_output/data/output5.txt", std::ofstream::out | std::ofstream::trunc);
#else
    std::ofstream ofs4;
    ofs4.open("x86simulator_output/data/output5.txt", std::ofstream::out | std::ofstream::trunc);
#endif


#ifndef __X86SIM__
    std::ofstream ofs5;
    ofs5.open("aiesimulator_output/data/output6.txt", std::ofstream::out | std::ofstream::trunc);
#else
    std::ofstream ofs5;
    ofs5.open("x86simulator_output/data/output6.txt", std::ofstream::out | std::ofstream::trunc);
#endif
/*	
	 std::ofstream ofs6;
    ofs6.open("aiesimulator_output/data/output7.txt", std::ofstream::out | std::ofstream::trunc);
	
	 std::ofstream ofs7;
    ofs7.open("aiesimulator_output/data/output8.txt", std::ofstream::out | std::ofstream::trunc);

   */ 
	for (int i=0; i<ofm_size/4; i++)
		ofs<<std::hex<<(uint32_t)ofmData[i]<<std::endl;
    ofs.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs1<<std::hex<<(uint32_t)ofmData1[i]<<std::endl;
    ofs1.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs2<<std::hex<<(uint32_t)ofmData2[i]<<std::endl;
    ofs2.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs3<<std::hex<<(uint32_t)ofmData3[i]<<std::endl;
    ofs3.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs4<<std::hex<<(uint32_t)ofmData4[i]<<std::endl;
    ofs4.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs5<<std::hex<<(uint32_t)ofmData5[i]<<std::endl;
    ofs5.close();
	/*
	for (int i=0; i<ofm_size/4; i++)
		ofs6<<std::hex<<(uint32_t)ofmData6[i]<<std::endl;
    ofs6.close();
	for (int i=0; i<ofm_size/4; i++)
		ofs7<<std::hex<<(uint32_t)ofmData7[i]<<std::endl;
    ofs7.close();
*/
	GMIO::free(ifmData);
    GMIO::free(ifmData1);
	GMIO::free(ifmData2);
	GMIO::free(ifmData3);
	GMIO::free(ifmData4);
	GMIO::free(ifmData5);
	//GMIO::free(ifmData6);
	//GMIO::free(ifmData7);
	GMIO::free(ofmData);
    GMIO::free(ofmData1);
	GMIO::free(ofmData2);
	GMIO::free(ofmData3);
	GMIO::free(ofmData4);
	GMIO::free(ofmData5);
	//GMIO::free(ofmData6);
	//GMIO::free(ofmData7);
    return 0;
}
