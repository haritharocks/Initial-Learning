#pragma once

#include "adf.h"

#include "kernels.h"

using namespace adf;

class TinyYoloLayer1 : public graph
{
public:
//col 1
        kernel k1;

        shared_buffer<uint8> ifm1;
        shared_buffer<uint8> ofm1;


        external_buffer<uint8> ifm_ddr1;
        external_buffer<uint8> ofm_ddr1;
	    external_buffer<uint8> ifm_ddr2;
        external_buffer<uint8> ofm_ddr2;
//col 2		
		kernel k2;

        shared_buffer<uint8> ifm2;
        shared_buffer<uint8> ofm2;


        external_buffer<uint8> ifm_ddr3;
        external_buffer<uint8> ofm_ddr3;
	    external_buffer<uint8> ifm_ddr4;
        external_buffer<uint8> ofm_ddr4;
//col 3		
		kernel k3;

        shared_buffer<uint8> ifm3;
        shared_buffer<uint8> ofm3;


        external_buffer<uint8> ifm_ddr5;
        external_buffer<uint8> ofm_ddr5;
	    external_buffer<uint8> ifm_ddr6;
        external_buffer<uint8> ofm_ddr6;
//col 4		
		kernel k4;

        shared_buffer<uint8> ifm4;
        shared_buffer<uint8> ofm4;


        external_buffer<uint8> ifm_ddr7;
        external_buffer<uint8> ofm_ddr7;
	    external_buffer<uint8> ifm_ddr8;
        external_buffer<uint8> ofm_ddr8;
    
    
    

    TinyYoloLayer1()
    {
                //edit the below line with passthoruh callback function
                k1 = kernel::create(pass_through1);
				//add source path 
                source(k1) = "src/kernels.cpp";
                runtime<ratio>(k1) = 0.5;
                repetition_count(k1) = 1;
               
         

        ifm1 = shared_buffer<uint8>::create({ 256 }, 2, 1);
        ofm1 = shared_buffer<uint8>::create({ 256 }, 1, 2);
        
       
        
        ifm_ddr1 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr1 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
	    ifm_ddr2 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr2 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
		
		 //location constraints
		 //DDR SHIM DMA
	location<dma>(ifm_ddr1.out[0]) = dma_channel(shim_tile, 2, 0, 0);
        location<dma>(ofm_ddr1.in[0]) = dma_channel(shim_tile, 2, 0, 0);
	location<dma>(ifm_ddr2.out[0]) = dma_channel(shim_tile, 2, 0, 1);
        location<dma>(ofm_ddr2.in[0]) = dma_channel(shim_tile, 2, 0, 1);

		 //MEMTILE DMA AND BUFFER
	location<buffer>(ifm1) = address(2, 0, 0);
        location<dma>(ifm1.in[0]) = dma_channel(memory_tile, 2, 0, 1);
		location<dma>(ifm1.in[1]) = dma_channel(memory_tile, 2, 0, 2);
        location<dma>(ifm1.out[0]) = dma_channel(memory_tile, 2, 0, 0);
        location<buffer>(ofm1) = address(2, 0, 0);
        location<dma>(ofm1.in[0]) = dma_channel(memory_tile, 2, 0, 0);
        location<dma>(ofm1.out[0]) = dma_channel(memory_tile, 2, 0, 1);
		 location<dma>(ofm1.out[1]) = dma_channel(memory_tile, 2, 0, 3);
		
		//location<buffer>(ifm) = address(6, 0, 0x100);
        
       // location<dma>(ifm.out[1]) = dma_channel(memory_tile, 6, 0, 2);
       // location<buffer>(ofm) = address(6, 0, 0x100);
       // location<dma>(ofm.in[1]) = dma_channel(memory_tile, 6, 0, 2);
       
		
		 //k1 TILE DMA AND BUFFER
		location<kernel>(k1) = tile(2, 0);
        location<buffer>(k1.in[0]) = { address(2,0,0), address(2,0,0x2000) };
        location<buffer>(k1.out[0]) = { address(2,0,0x4000), address(2,0,0x6000) };
        location<dma>(k1.in[0]) = dma_channel(aie_tile, 2, 0, 0);
        location<dma>(k1.out[0]) = dma_channel(aie_tile, 2, 0, 0);
		
		 //read from DDR ifm 
		
		
		connect<stream>(ifm_ddr1.out[0], ifm1.in[0]);
        read_access(ifm_ddr1.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		write_access(ifm1.in[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		
		connect<stream>(ifm_ddr2.out[0], ifm1.in[1]);
        read_access(ifm_ddr2.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		write_access(ifm1.in[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
       
         //read from ifm memtile
	   
         connect(ifm1.out[0], k1.in[0]);
		 dimensions(k1.in[0])={256};
         read_access(ifm1.out[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(k1.out[0],ofm1.in[0]);
		 dimensions(k1.out[0])={256};
		 write_access(ofm1.in[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(ofm1.out[0],ofm_ddr1.in[0]);
		 write_access(ofm_ddr1.in[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 read_access(ofm1.out[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 
		 connect(ofm1.out[1],ofm_ddr2.in[0]);
	     write_access(ofm_ddr2.in[0]) =tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		 read_access(ofm1.out[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		  
		  
		  
		  
		  
		  
                //edit the below line with passthoruh callback function
                k2 = kernel::create(pass_through1);
				//add source path 
                source(k2) = "src/kernels.cpp";
                runtime<ratio>(k2) = 0.5;
                repetition_count(k2) = 1;
               
         

        ifm2 = shared_buffer<uint8>::create({ 256 }, 2, 1);
        ofm2 = shared_buffer<uint8>::create({ 256 }, 1, 2);
        
       
        
        ifm_ddr3 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr3 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
	    ifm_ddr4 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr4 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
		
		 //location constraints
		 //DDR SHIM DMA
	location<dma>(ifm_ddr3.out[0]) = dma_channel(shim_tile, 6, 0, 0);
        location<dma>(ofm_ddr3.in[0]) = dma_channel(shim_tile, 6, 0, 0);
	location<dma>(ifm_ddr4.out[0]) = dma_channel(shim_tile, 6, 0, 1);
        location<dma>(ofm_ddr4.in[0]) = dma_channel(shim_tile, 6, 0, 1);

		 //MEMTILE DMA AND BUFFER
	location<buffer>(ifm2) = address(6, 0, 0);
        location<dma>(ifm2.in[0]) = dma_channel(memory_tile, 6, 0, 1);
		location<dma>(ifm2.in[1]) = dma_channel(memory_tile, 6, 0, 2);
        location<dma>(ifm2.out[0]) = dma_channel(memory_tile, 6, 0, 0);
        location<buffer>(ofm2) = address(6, 0, 0);
        location<dma>(ofm2.in[0]) = dma_channel(memory_tile, 6, 0, 0);
        location<dma>(ofm2.out[0]) = dma_channel(memory_tile, 6, 0, 1);
		 location<dma>(ofm2.out[1]) = dma_channel(memory_tile, 6, 0, 3);
		
		//location<buffer>(ifm) = address(6, 0, 0x100);
        
       // location<dma>(ifm.out[1]) = dma_channel(memory_tile, 6, 0, 2);
       // location<buffer>(ofm) = address(6, 0, 0x100);
       // location<dma>(ofm.in[1]) = dma_channel(memory_tile, 6, 0, 2);
       
		
		 //k1 TILE DMA AND BUFFER
		location<kernel>(k2) = tile(6, 0);
        location<buffer>(k2.in[0]) = { address(6,0,0), address(6,0,0x2000) };
        location<buffer>(k2.out[0]) = { address(6,0,0x4000), address(6,0,0x6000) };
        location<dma>(k2.in[0]) = dma_channel(aie_tile, 6, 0, 0);
        location<dma>(k2.out[0]) = dma_channel(aie_tile, 6, 0, 0);
		
		 //read from DDR ifm 
		
		
		connect<stream>(ifm_ddr3.out[0], ifm2.in[0]);
        read_access(ifm_ddr3.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		write_access(ifm2.in[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		
		connect<stream>(ifm_ddr4.out[0], ifm2.in[1]);
        read_access(ifm_ddr4.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		write_access(ifm2.in[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
       
         //read from ifm memtile
	   
         connect(ifm2.out[0], k2.in[0]);
		 dimensions(k2.in[0])={256};
         read_access(ifm2.out[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(k2.out[0],ofm2.in[0]);
		 dimensions(k2.out[0])={256};
		 write_access(ofm2.in[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(ofm2.out[0],ofm_ddr3.in[0]);
		 write_access(ofm_ddr3.in[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 read_access(ofm2.out[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 
		 connect(ofm2.out[1],ofm_ddr4.in[0]);
	     write_access(ofm_ddr4.in[0]) =tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		 read_access(ofm2.out[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		  
		  
		  
                //edit the below line with passthoruh callback function
                k3 = kernel::create(pass_through1);
				//add source path 
                source(k3) = "src/kernels.cpp";
                runtime<ratio>(k3) = 0.5;
                repetition_count(k3) = 1;
               
         

        ifm3 = shared_buffer<uint8>::create({ 256 }, 2, 1);
        ofm3 = shared_buffer<uint8>::create({ 256 }, 1, 2);
        
       
        
        ifm_ddr5 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr5 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
	    ifm_ddr6 = external_buffer<uint8>::create({ 128 }, 0, 1);
        ofm_ddr6 = external_buffer<uint8>::create({ 128 }, 1, 0);
		
		
		 //location constraints
		 //DDR SHIM DMA
	location<dma>(ifm_ddr5.out[0]) = dma_channel(shim_tile, 10, 0, 0);
        location<dma>(ofm_ddr5.in[0]) = dma_channel(shim_tile, 10, 0, 0);
	location<dma>(ifm_ddr6.out[0]) = dma_channel(shim_tile, 10, 0, 1);
        location<dma>(ofm_ddr6.in[0]) = dma_channel(shim_tile, 10, 0, 1);

		 //MEMTILE DMA AND BUFFER
	location<buffer>(ifm3) = address(10, 0, 0);
        location<dma>(ifm3.in[0]) = dma_channel(memory_tile, 10, 0, 1);
		location<dma>(ifm3.in[1]) = dma_channel(memory_tile, 10, 0, 2);
        location<dma>(ifm3.out[0]) = dma_channel(memory_tile, 10, 0, 0);
        location<buffer>(ofm3) = address(10, 0, 0);
        location<dma>(ofm3.in[0]) = dma_channel(memory_tile, 10, 0, 0);
        location<dma>(ofm3.out[0]) = dma_channel(memory_tile, 10, 0, 1);
		 location<dma>(ofm3.out[1]) = dma_channel(memory_tile, 10, 0, 3);
		
		//location<buffer>(ifm) = address(6, 0, 0x100);
        
       // location<dma>(ifm.out[1]) = dma_channel(memory_tile, 6, 0, 2);
       // location<buffer>(ofm) = address(6, 0, 0x100);
       // location<dma>(ofm.in[1]) = dma_channel(memory_tile, 6, 0, 2);
       
		
		 //k1 TILE DMA AND BUFFER
		location<kernel>(k3) = tile(10, 0);
        location<buffer>(k3.in[0]) = { address(10,0,0), address(10,0,0x2000) };
        location<buffer>(k3.out[0]) = { address(10,0,0x4000), address(10,0,0x6000) };
        location<dma>(k3.in[0]) = dma_channel(aie_tile, 10, 0, 0);
        location<dma>(k3.out[0]) = dma_channel(aie_tile, 10, 0, 0);
		
		 //read from DDR ifm 
		
		
		connect<stream>(ifm_ddr5.out[0], ifm3.in[0]);
        read_access(ifm_ddr5.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		write_access(ifm3.in[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		
		connect<stream>(ifm_ddr6.out[0], ifm3.in[1]);
        read_access(ifm_ddr6.out[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		write_access(ifm3.in[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
       
         //read from ifm memtile
	   
         connect(ifm3.out[0], k3.in[0]);
		 dimensions(k3.in[0])={256};
         read_access(ifm3.out[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(k3.out[0],ofm3.in[0]);
		 dimensions(k3.out[0])={256};
		 write_access(ofm3.in[0]) =tiling({.buffer_dimension = { 256 },.tiling_dimension = { 256 },.offset = { 0 }});
            
         connect(ofm3.out[0],ofm_ddr5.in[0]);
		 write_access(ofm_ddr5.in[0]) = tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 read_access(ofm3.out[0]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1 }}});
		 
		 connect(ofm3.out[1],ofm_ddr6.in[0]);
	     write_access(ofm_ddr6.in[0]) =tiling({ .buffer_dimension = { 128 },.tiling_dimension = { 128 },.offset = { 0 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		 read_access(ofm3.out[1]) = tiling({ .buffer_dimension = { 256 },.tiling_dimension = { 128 },.offset = { 128 } ,.tile_traversal = { { .dimension = 0,.stride = 128,.wrap = 1}}});
		  
		  

      

	}

		  
};

