#ifndef KERNELS_H
#define KERNELS_H

#include "adf.h"

using namespace adf;

void pass_through1(adf::input_buffer<uint8>& in,adf::output_buffer<uint8>& out);

#endif
