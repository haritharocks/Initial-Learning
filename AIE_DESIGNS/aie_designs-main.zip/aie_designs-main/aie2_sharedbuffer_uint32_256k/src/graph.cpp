#include "graph.h"
#include <fstream>

FlexMLOneKernelOneLayerGraph g;

int main()
{
    g.init();

    uint32_t* ifmData = (uint32_t*)GMIO::malloc(65536*sizeof(uint32_t));
    for (int i=0; i<65536; i++)
        ifmData[i] = 1;
    
   // uint8_t* wtsData = (uint8_t*)GMIO::malloc(1000*sizeof(uint8_t));
   // for (int i=0; i<1000; i++)
     //   wtsData[i] = i;
    
    uint32_t* ofmData = (uint32_t*)GMIO::malloc(65536*sizeof(uint32_t));
    
    g.ifm_ddr.gm2aie_nb(ifmData, 65536*sizeof(uint32_t));
   // g.wts_ddr.gm2aie_nb(wtsData, 1000*sizeof(uint8_t));
    g.ofm_ddr.aie2gm_nb(ofmData, 65536*sizeof(uint32_t));

    g.run(1);
   // printf("after run");
    g.ofm_ddr.wait();
   // printf("after ddr wait");
    g.end();

#ifndef __X86SIM__    
    system("mkdir -p  aiesimulator_output/data");
    std::ofstream ofs;
    ofs.open("aiesimulator_output/data/output.txt", std::ofstream::out | std::ofstream::trunc);
#else
    system("mkdir -p x86simulator_output/data");
    std::ofstream ofs;
    ofs.open("x86simulator_output/data/output.txt", std::ofstream::out | std::ofstream::trunc);
#endif
    
	for (int i=0; i<65536; i++)
    {
//        unsigned val = ofmData[i];
//	 printf("%hd \n",ofmData[i]);
	ofs<<ofmData[i]<<std::endl;
    }
    ofs.close();

	GMIO::free(ifmData);
//	GMIO::free(wtsData);
	GMIO::free(ofmData);

	
    return 0;
}
