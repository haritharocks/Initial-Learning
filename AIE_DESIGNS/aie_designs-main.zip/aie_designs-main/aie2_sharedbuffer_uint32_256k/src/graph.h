#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;

class FlexMLOneKernelOneLayerGraph : public graph
{
public:
    kernel superkernel;

    shared_buffer<uint32> ifm;
    shared_buffer<uint32> ofm;
//    shared_buffer<uint8> wts;

    input_gmio ifm_ddr;
  //  input_gmio wts_ddr;
    output_gmio ofm_ddr;

    FlexMLOneKernelOneLayerGraph()
    {
        superkernel = kernel::create(dummy_conv2d);
        source(superkernel) = "src/kernels.cpp";
        runtime<ratio>(superkernel) = 0.9;
        repetition_count(superkernel) = 8;

        ifm = shared_buffer<uint32>::create({ 65536 }, 1, 1); //IC:16, W:32, H:32, assuming channel is D0
        ofm = shared_buffer<uint32>::create({ 65536 }, 1, 1); //OC:64, W:32, H:32
       // wts = shared_buffer<uint8>::create({ 1000 }, 1, 1); //1000 is a dummy 1D size for weight (4D tensor + bias + header)

        ifm_ddr = input_gmio::create("ifm_ddr", 64, 1);
       // wts_ddr = input_gmio::create("wts_ddr", 64, 1);
        ofm_ddr = output_gmio::create("ofm_ddr", 64, 1);

        connect<stream>(ifm_ddr.out[0], ifm.in[0]);
        tiling_parameters ifm_ddr_pattern = { .buffer_dimension = { 65536 },.tiling_dimension = { 65536 },.offset = { 0 } };
        write_access(ifm.in[0]) = tiling(ifm_ddr_pattern);

       // connect<stream>(wts_ddr.out[0], wts.in[0]);
       // tiling_parameters wts_ddr_pattern = { .buffer_dimension = { 1000 },.tiling_dimension = { 1000 },.offset = { 0 } };
       // write_access(wts.in[0]) = tiling(wts_ddr_pattern);

      //  connect<stream, window<100*sizeof(uint8)>>(ifm.out[0], superkernel.in[0]);
		connect(ifm.out[0], superkernel.in[0]);
		dimensions(superkernel.in[0])={8192};
//		for( int i=0;i<16;i++)
//		{
        tiling_parameters ifm_pattern = { .buffer_dimension = { 65536 },.tiling_dimension = { 8192 },.offset = { 0 },.tile_traversal = { { .dimension = 0,.stride = 8192,.wrap = 8}} };
        read_access(ifm.out[0]) = tiling(ifm_pattern);
//		}
        //connect<stream, window<1000*sizeof(uint8)>>(wts.out[0], superkernel.in[1]);
       // async(superkernel.in[1]);
       // tiling_parameters wts_pattern = { .buffer_dimension = { 1000 },.tiling_dimension = { 1000 },.offset = { 0 } };
       // read_access(wts.out[0]) = tiling(wts_pattern);

        //connect<window<100*sizeof(uint8)>, stream>(superkernel.out[0], ofm.in[0]);
		connect(superkernel.out[0], ofm.in[0]);
		dimensions(superkernel.out[0])={8192};
	//	for( int i=0;i<16;i++)
	//	{
        tiling_parameters ofm_pattern = { .buffer_dimension = { 65536 },.tiling_dimension = { 8192 },.offset = { 0 },.tile_traversal = { { .dimension = 0,.stride = 8192,.wrap = 8} } };
        write_access(ofm.in[0]) = tiling(ofm_pattern);
//		}
        connect<stream>(ofm.out[0], ofm_ddr.in[0]);
        tiling_parameters ofm_ddr_pattern = { .buffer_dimension = { 65536 },.tiling_dimension = { 65536 },.offset = { 0 } };
        read_access(ofm.out[0]) = tiling(ofm_ddr_pattern);
    }
};
