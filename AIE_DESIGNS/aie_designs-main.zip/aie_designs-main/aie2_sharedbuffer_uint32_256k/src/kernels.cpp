#include "kernels.h"


void dummy_conv2d(adf::input_buffer<uint32>& ifm,adf::output_buffer<uint32>& ofm)
{
  //  if (iteration == 0)
    //    window_acquire(wts);
    
    uint32* pIn = (uint32*)ifm.data();
    uint32* pOut = (uint32*)ofm.data();
    //ignore weight

    //for (int i = 0; i<1024; i++)
    //    printf("%d ", pIn[i]);
    //printf("\n");
    
    for (int oh = 0; oh < 8192; oh++)
    {
//        for (int ow = 0; ow < 4; ow++)
  //      {
    //        for (int oc = 0; oc < 64; oc++)
      //      {
        //        int ic = oc / 4;
        //        int ih = oh * 2;
          //      int iw = ow * 2;
           //     int i_idx = ih * 16 * 8 + iw * 16 + ic;
            //    int o_idx = oh * 64 * 4 + ow * 64 + oc;

                pOut[oh] = pIn[oh];
            }
       // }
   // }
    
   // iteration++;
  //  if (iteration == 16)
  //  {
    //    iteration = 0;
      //  window_release(wts);
  //  }
}
