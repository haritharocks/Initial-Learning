#pragma once

#include "adf.h"
using namespace adf;
void dummy_conv2d(adf::input_buffer<uint32>& ifm,adf:: output_buffer<uint32>& ofm);
