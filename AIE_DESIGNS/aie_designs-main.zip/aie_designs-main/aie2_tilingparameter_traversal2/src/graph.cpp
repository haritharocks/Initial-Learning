#include "graph.h"
#include "adf.h"
#include<fstream>
#include<iostream>

#define IN1_FILE  "data/in1.txt"
#define IN2_FILE  "data/in2.txt"
#define OUT_FILE  "aiesimulator_output/data/output.txt"



//GMIO *in_1 = new GMIO("IN1", 64, 1000);
//GMIO *in_2 = new GMIO("IN2", 64, 1000);
//GMIO *outt = new GMIO("OUT", 64, 1000);


//simulation::platform<2,1> plat(in_1,in_2,outt);

mygraph g;

//connect<> net0(plat.src[0], g.in1);
//connect<> net1(plat.src[1], g.in2);
//connect<> net3(g.out, plat.sink[0]);



void write_file(FILE *fpout, int *out_buffer, int n) {
     for(int i=0; i<n; i++) {
         fprintf(fpout,"%d\n", *(out_buffer+i)) ;
     }
}

void read_file(FILE *fpin, int *in_buffer, int n) {     
     int temp ;
     for(int i=0; i<n; i++) {
	 fscanf(fpin,"%d\n", &temp) ;	 
	 *(in_buffer+i) = temp;
	 //printf("%d\n",*(in_buffer+i)); 
     }
}


int main(void) {

    FILE *fpin1 = NULL;
    FILE *fpin2 = NULL;
    FILE *fpout = NULL;
   
    int *in1_buffer  = (int*)GMIO::malloc(60*sizeof(int));
    int *in2_buffer  = (int*)GMIO::malloc(60*sizeof(int));
    int *out_buffer  = (int*)GMIO::malloc(60*sizeof(int));
	system("mkdir -p aiesimulator_output/data");
    
    fpin1 = fopen(IN1_FILE, "r");
    fpin2 = fopen(IN2_FILE, "r");
    fpout = fopen(OUT_FILE, "w");
  

    g.init();

    printf(" after init");


    if (fpin1==NULL)
    {
       
       return -1;
    }
    else
    {	    
      
       read_file(fpin1, in1_buffer, 60);
    }

   if (fpin2==NULL)
    {
       
       return -1;
    }
    else
    {	    
      
       read_file(fpin2, in2_buffer, 60);
    }
    
    
   
    g.in1.gm2aie_nb(in1_buffer,60*sizeof(int));

    g.in2.gm2aie_nb(in2_buffer,60*sizeof(int));

    g.out.aie2gm_nb(out_buffer,36*sizeof(int));
   

     g.run(1) ;	
    
   
     g.out.wait();

    

   if ((fpout==NULL))
    {
   
       return -1;
    }
   else
    {	    
     
       write_file(fpout,out_buffer,36);
     
    }
        
    GMIO::free(in1_buffer);
    GMIO::free(in2_buffer);
    GMIO::free(out_buffer);
 

    fclose(fpin1);
    fclose(fpin2);
    fclose(fpout);
   

    g.end();

    return 0 ;
}



/*
#include "graph.h"
#include <fstream>

//#ifdef __AIESIM__
//#include "../aie_runtime_control.cpp"
//#endif

mygraph g;

int main(void)
{
    g.init();
    
    int32_t* in1_Data = (int32_t*)GMIO::malloc(60* sizeof(int32_t));
    for (int i = 0; i < 60; i++)
        in1_Data[i] = i;
    g.in1.setAddress(in1_Data);
	
	int32_t* in2_Data = (int32_t*)GMIO::malloc(60* sizeof(int32_t));
    for (int i = 0; i < 60; i++)
        in2_Data[i] = i;
    g.in2.setAddress(in2_Data);

    

    uint32_t* out_Data = (uint32_t*)GMIO::malloc(60* sizeof(int32_t));
    g.out.setAddress(out_Data);
    
    g.run(1);
//#ifdef __AIESIM__
  //  executeRuntimeControl();
//#endif
    g.end();
    
    system("mkdir aiesimulator_output/data");
    std::ofstream ofs;
    ofs.open("aiesimulator_output/data/output.txt", std::ofstream::out | std::ofstream::trunc);
    for (int i = 0; i < 36; i++)
    {
        ofs << out_Data[i] << std::endl;
        std::cout << out_Data[i] << std::endl;
    }   
    ofs.close();

    GMIO::free(in1_Data);
    //GMIO::free(wtsDataLayer1);
    GMIO::free(in2_Data);
    GMIO::free(out_Data);

    return 0;
}
*/