#ifndef _GRAPH_H
#define  _GRAPH_H

#include "adf.h"
#include "kernels.h"


using namespace adf;

//class mygraph : public graph
class mygraph :public graph{

public:
        kernel k1;

        shared_buffer<int> mtx;

     
        //port<input> in1;
        //port<input> in2;
        //port<output> out;
		
	input_gmio in1;
    input_gmio in2;
    output_gmio out;
      

          mygraph()
        {                                          

         
	 k1=kernel::create(pass_through1);
	 source(k1) = "src/kernels.cpp";
         runtime<ratio>(k1) = 0.5;
		 repetition_count(k1)=6;
	
	
	  mtx = shared_buffer<int>::create({10,6}, 2, 1); 
	  
	    in1 = input_gmio::create("in1_ddr", 64, 1);
       // wts_ddr = input_gmio::create("wts_ddr", 64, 1);
        in2 = input_gmio::create("in2_ddr", 64, 1);
		out=output_gmio::create("out_ddr",64,1);
	  
	   
	
	 //sharedbuffer input 1
	 
	  connect<stream>(in1.out[0],mtx.in[0]);
	 // connect<stream>(in1,mtx.in[0]);
	      //read_access(in1.out[0])=tiling({.buffer_dimension = {10,6},.tiling_dimension = {3,2},.offset = { 0, 0},.tile_traversal = {{ .dimension = 1,.stride = 2,.wrap = 3},{ .dimension = 0,.stride = 3,.wrap = 2 } } });
          tiling_parameters in1_ddr_pattern = {.buffer_dimension = {10,6},.tiling_dimension = {3,2},.offset = { 0, 0},.tile_traversal = {{ .dimension = 1,.stride = 2,.wrap = 3},{ .dimension = 0,.stride = 3,.wrap = 2 } },/*.repetition=6 */};
          write_access(mtx.in[0]) = tiling(in1_ddr_pattern);
	  
	  //sharedbuffer input 2
 
	  connect<stream>(in2.out[0],mtx.in[1]);
	 //     connect<stream>(in2,mtx.in[1]);
	      //read_access(in2.out[0])=tiling({.buffer_dimension = {10,6},.tiling_dimension = {3,2},.offset = { 6, 0},.tile_traversal = {{ .dimension = 1,.stride = 2,.wrap = 3},{ .dimension = 0,.stride = 3,.wrap = 2 } } });
          tiling_parameters in2_ddr_pattern = {.buffer_dimension = {10,6},.tiling_dimension = {2,2},.offset = { 6, 0},.tile_traversal = {{ .dimension = 1,.stride = 2,.wrap = 3},{ .dimension = 0,.stride = 2,.wrap = 2 } } };
          write_access(mtx.in[1]) = tiling(in2_ddr_pattern);
	  
	   //sharedbuffer output to kernel in

	  //connect<stream, window<144>>(mtx.out[0], k1.in[0]);
	      connect(mtx.out[0], k1.in[0]);
		  dimensions(k1.in[0])={3,2};
          tiling_parameters k_pattern = {.buffer_dimension = {10,6},.tiling_dimension = {3,2},.offset = { 2, 0},.tile_traversal = {{ .dimension = 1,.stride = 2,.wrap = 3},{ .dimension = 0,.stride = 3,.wrap = 2 } } };
          read_access(mtx.out[0]) = tiling(k_pattern);
	  
          //kernelout to outputfile 
 
	   connect(k1.out[0],out.in[0]);
       dimensions(k1.out[0])={3,2};    
	   
}
};

#endif
     
	 
	 
