#include "kernels.h"

void pass_through1(adf::input_buffer<int32,adf::extents<adf::inherited_extent,adf::inherited_extent>>& in,adf::output_buffer<int32,adf::extents<adf::inherited_extent,adf::inherited_extent>>& out)
{
	 int32* inBuf = in.data();
    //uint32* wtsBuf = wts.data();
     int32* outBuf = out.data();
    for (int i=0; i<6; i++)
{
       //window_writeincr(out,window_readincr(in));
	
	outBuf[i] = inBuf[i];
	
}
}

