#ifndef KERNELS_H
#define KERNELS_H

#include "adf.h"

//using namespace adf;

void pass_through1(adf::input_buffer<int32,adf::extents<adf::inherited_extent,adf::inherited_extent>>& in,adf::output_buffer<int32,adf::extents<adf::inherited_extent,adf::inherited_extent>>& out);

#endif
