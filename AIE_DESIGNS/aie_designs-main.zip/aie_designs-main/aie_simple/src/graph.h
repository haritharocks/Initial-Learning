#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;

class SimpleGraph : public adf::graph {
private:
    adf::kernel first, second;
public:
    input_plio in;
    output_plio out;
public:
    SimpleGraph() {
        first = adf::kernel::create(simple);
        second = adf::kernel::create(simple);

        source(first) = "kernels.cc";
        source(second) = "kernels.cc";

        runtime<ratio>(first) = 0.1;
        runtime<ratio>(second) = 0.1;

        in  = input_plio::create(plio_32_bits, "data/input.txt");
        out = output_plio::create(plio_32_bits, "data/output.txt");
        connect(in.out[0], first.in[0]);
        connect(first.out[0], second.in[0]);
        connect(second.out[0], out.in[0]);
        dimensions(first.in[0])   = {128};
        dimensions(first.out[0])  = {128};
        dimensions(second.in[0])  = {128};
        dimensions(second.out[0]) = {128};
    }
};
