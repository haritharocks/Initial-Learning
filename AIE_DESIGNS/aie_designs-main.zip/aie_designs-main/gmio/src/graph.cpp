#include "graph.h"

using namespace adf;


SimpleGraph mygraph;

int main(void) { 
    adf::return_code ret;
    const uint32_t c_blkSize = 256;
    const uint32_t c_blkSizeInByte = c_blkSize*sizeof(int32);
    int32 *inputArray  = (int32*)GMIO::malloc(c_blkSizeInByte);
    int32 *outputArray = (int32*)GMIO::malloc(c_blkSizeInByte);

    //Provide input data to AI Engine in input Array
    for (int i = 0 ; i < c_blkSize; i++){
        inputArray[i] = i;
    }
    mygraph.init();
    mygraph.gmioIn.gm2aie_nb(inputArray, c_blkSizeInByte);
    mygraph.gmioOut.aie2gm_nb(outputArray, c_blkSizeInByte);

    ret=mygraph.run(8/*Number of iterations*/);
    mygraph.gmioOut.wait();

    for (int i = 0 ; i < c_blkSize; i++){
        printf("input=%d and output=%d\n",inputArray[i],outputArray[i]);
    }

    GMIO::free(inputArray);
    GMIO::free(outputArray);
    if(ret!=adf::ok){
        printf("Run failed\n");
        return ret;
    }
    ret=mygraph.end();
    if(ret!=adf::ok){
        printf("End failed\n");
        return ret;
    }
    return 0;
}
