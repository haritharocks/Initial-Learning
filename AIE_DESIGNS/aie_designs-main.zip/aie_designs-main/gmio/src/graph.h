#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;

class SimpleGraph : public adf::graph {
private:
    adf::kernel first, second;
public:
    input_gmio gmioIn;
    output_gmio gmioOut;
public:
    SimpleGraph() {
        first = adf::kernel::create(simple);
        second = adf::kernel::create(simple);

        source(first) = "kernels.cc";
        source(second) = "kernels.cc";

        runtime<ratio>(first) = 0.9;
        runtime<ratio>(second) = 0.9;

        gmioIn = input_gmio::create("gmioIn",64,1000); 
        gmioOut = output_gmio::create("gmioOut",64,1000);
        connect(gmioIn.out[0], first.in[0]);
        connect(first.out[0], second.in[0]);
        connect(second.out[0], gmioOut.in[0]);
        dimensions(first.in[0])  = {32};
        dimensions(first.out[0]) = {32};
        dimensions(second.in[0]) = {32};
        dimensions(second.out[0])= {32};
    }
};
