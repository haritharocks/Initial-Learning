#define NUM_SAMPLES 32
#include <adf.h>
#include "kernels.h"
void simple(adf::input_buffer_1d<int32> & __restrict in,
adf::output_buffer_1d<int32> & __restrict out)
{
    int32* __restrict in_t = in.data();
    int32* __restrict out_t = out.data();
    for (unsigned i=0; i<NUM_SAMPLES; i++) {
        *out_t++ = 1 + *in_t++;
    }
}
