#ifndef FUNCTION_KERNELS_H
#define FUNCTION_KERNELS_H
#include "aie_api/aie.hpp"
#include "aie_api/aie_adf.hpp"
void simple(adf::input_buffer_1d<int16> & __restrict in, adf::output_buffer_1d<int16> & __restrict out);
#endif
