#include "graph.h"
#include <fstream>
#ifdef __AIESIM__
#include "../aie_runtime_control.cpp"
#endif

using namespace adf;


SimpleGraph mygraph;

int main(int argc, char ** argv) { 

    int32* inputArray0 = (int32*)GMIO::malloc(256*sizeof(int32));
	int32* outputArray0 = (int32*)GMIO::malloc(256*sizeof(int32));

    int32* inputArray1 = (int32*)GMIO::malloc(256*sizeof(int32));
	int32* outputArray1 = (int32*)GMIO::malloc(256*sizeof(int32));

for (int i=0; i<256; i++) {
		inputArray0[i] = i+1;
	    inputArray1[i] = i+1;
}
    std::ofstream ofs0;
    std::ofstream ofs1;
#ifndef __X86SIM__
    system("mkdir aiesimulator_output/data");
    ofs0.open("aiesimulator_output/data/output_gm0.txt", std::ofstream::out | std::ofstream::trunc);
    ofs1.open("aiesimulator_output/data/output_gm1.txt", std::ofstream::out | std::ofstream::trunc);
#else
    system("mkdir x86simulator_output/data");
    ofs0.open("x86simulator_output/data/output_gm0.txt", std::ofstream::out | std::ofstream::trunc);
    ofs1.open("x86simulator_output/data/output_gm1.txt", std::ofstream::out | std::ofstream::trunc);
#endif



  mygraph.init();
  //GMIO Init Removed

  
  
  mygraph.run(1);
  
  
        mygraph.gm_in0.gm2aie_nb(&inputArray0[0], 32*sizeof(int32));
        mygraph.gm_in1.gm2aie_nb(&inputArray1[0], 32*sizeof(int32));
        mygraph.gm_out0.aie2gm_nb(&outputArray0[0], 32*sizeof(int32));
        mygraph.gm_out1.aie2gm_nb(&outputArray1[0], 32*sizeof(int32));

    mygraph.gm_out0.wait(); //assuming data from gm1 are processed by the graph and output to gm2
    mygraph.gm_out1.wait(); //assuming data from gm1 are processed by the graph and output to gm2
	
	for (int i=0; i<32; i++)
	{
		//std::cout<<outputArray0[i]<<", ";
		ofs0<<outputArray0[i]<<std::endl;
		ofs1<<outputArray1[i]<<std::endl;
	}

    mygraph.end();
	
	ofs0.close();
	ofs1.close();  
  
  
    GMIO::free(inputArray0);
    GMIO::free(outputArray0);
	  
    GMIO::free(inputArray1);
    GMIO::free(outputArray1);
  
  
return 0;

}
