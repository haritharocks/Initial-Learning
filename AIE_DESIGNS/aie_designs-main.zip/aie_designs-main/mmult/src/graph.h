#pragma once

#include "adf.h"
//#include "tiling_parameters.h"
#include "mmult.h"

using namespace adf;

class SimpleGraph : public adf::graph {
public:
    output_plio out;
    input_plio in0,in1;
private:
    adf::kernel k;
    shared_buffer<int8> mtxA,mtxB,mtxC;
public:
    SimpleGraph() {
        out=output_plio::create("Dataout0", plio_64_bits, "data/output0.txt");
        in0=input_plio::create("Datain0", plio_64_bits, "data/matA.txt");
        in1=input_plio::create("Datain1", plio_64_bits, "data/matB.txt");

        k = adf::kernel::create(matrix_mul);
        adf::source(k) = "mmult.cc";
        runtime<ratio>(k) = 0.9;

        mtxA = shared_buffer<int8>::create({64,64}, 1, 1);//elements
        mtxB = shared_buffer<int8>::create({64,64}, 1, 1);
        mtxC = shared_buffer<int8>::create({64,64}, 1, 1);

        adf::connect(in0.out[0], mtxA.in[0]);
        adf::connect(in1.out[0], mtxB.in[0]);
        adf::connect(mtxA.out[0], k.in[0]);
        adf::connect(mtxB.out[0], k.in[1]);
        adf::connect(k.out[0], mtxC.in[0]);
        adf::connect(mtxC.out[0], out.in[0]);
        
        num_buffers(mtxA)=2;
        num_buffers(mtxB)=2;
        num_buffers(mtxC)=2;

        write_access(mtxA.in[0]) = tiling(
            {.buffer_dimension={64,64}, .tiling_dimension={64,64}, .offset={0,0}}
        ); //Write 'mtxA' data to MEM tile

        write_access(mtxB.in[0]) = tiling(
            {.buffer_dimension={64,64}, .tiling_dimension={64,64}, .offset={0,0}
        }); //Write 'mtxB' data to MEM tile

        write_access(mtxC.in[0]) = tiling(
            { .buffer_dimension = { 64,64 },.tiling_dimension = { 8, 4 }, .offset = { 0, 0 }, 
            .tile_traversal = 
                {{.dimension=0, .stride=8, .wrap=8},
                {.dimension=1, .stride=4, .wrap=16}} }
            ); //in elements //matC re-arrange 4x8

        read_access(mtxA.out[0]) = tiling(
            { .buffer_dimension = { 64,64 },.tiling_dimension = { 16, 4 }, .offset = { 0, 0 },
            .tile_traversal =
                {{.dimension=0, .stride=16, .wrap=4},
                {.dimension=1, .stride=4, .wrap=16}} }
        );//matA re-arrange 4x16

        read_access(mtxB.out[0]) = tiling(
            { .buffer_dimension = { 64,64 },.tiling_dimension = { 8, 16 }, .offset = { 0, 0 },
            .tile_traversal = 
                {{.dimension=0, .stride=8, .wrap=8},
                {.dimension=1, .stride=16, .wrap=4}} }
            );//matB re-arrange 16x8

        read_access(mtxC.out[0]) = tiling(
            {.buffer_dimension={64,64}, .tiling_dimension={64,64}, .offset={0,0}
        });

        adf::dimensions(k.in[0])={4096};//elements
        adf::dimensions(k.in[1])={4096};
        adf::dimensions(k.out[0])={4096};
    }
};
