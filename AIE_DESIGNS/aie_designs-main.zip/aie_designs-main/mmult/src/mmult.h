#ifndef KERNELS_H
#define KERNELS_H

#include "adf.h"

using namespace adf;

void matrix_mul(input_buffer_1d<int8>  & __restrict matA,
                input_buffer_1d<int8>  & __restrict matB, 
                output_buffer_1d<int8> & __restrict matC);
#endif
