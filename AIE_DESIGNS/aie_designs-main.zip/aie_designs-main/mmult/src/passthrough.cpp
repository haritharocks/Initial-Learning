#include "passthrough.h"
#include<adf.h>

void PassThrough(adf::input_buffer<uint8>& in,adf::output_buffer<uint8>& out)
{
	



	uint8* pIn = (uint8*)in.data();
    uint8* pOut = (uint8*)out.data();
   
    
    for (int oh = 0; oh <256; oh++)
    {


                pOut[oh] = pIn[oh];
       
    }
    
}



	
     
