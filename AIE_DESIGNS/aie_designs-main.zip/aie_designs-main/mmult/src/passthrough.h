#ifndef KERNELS_H
#define KERNELS_H

#include "adf.h"

using namespace adf;

void PassThrough(adf::input_buffer<uint8>& in,adf::output_buffer<uint8>& out);

#endif
