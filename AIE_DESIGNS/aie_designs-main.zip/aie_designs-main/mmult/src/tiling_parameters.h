#define NITERATIONS 2
#define NPARTS 2
#define NFRAMES_1 2
#define NFRAMES_2 2
#define NVECTORS_1 2
#define NVECTORS_2 2
#define VECTOR_LENGTH_1 4
#define VECTOR_LENGTH_2 4
// Complete Dataset sizes
const uint32_t totalSize1 =
NITERATIONS*NPARTS*NFRAMES_1*NVECTORS_1*VECTOR_LENGTH_1;
const uint32_t totalSize2 =
NITERATIONS*NPARTS*NFRAMES_2*NVECTORS_2*VECTOR_LENGTH_2;
// Input and Output DDR size for all dimensions
const std::vector<uint32_t> ddr_size1 = { VECTOR_LENGTH_1*NVECTORS_1,
NFRAMES_1, NPARTS};
const std::vector<uint32_t> ddr_size2 = { VECTOR_LENGTH_2*NVECTORS_2,
NFRAMES_2, NPARTS};
// MEM Tile data size
const std::vector<uint32_t> shared_mem_size1 = {VECTOR_LENGTH_1,NVECTORS_1,
NFRAMES_1};
const std::vector<uint32_t> shared_mem_size2 = {VECTOR_LENGTH_2,NVECTORS_2,
NFRAMES_2};
// AI Engine-ML buffer size
const std::vector<uint32_t> buffer_size1 = {VECTOR_LENGTH_1,NVECTORS_1};
const std::vector<uint32_t> buffer_size2 = {VECTOR_LENGTH_2,NVECTORS_2};
// Parameter given to the kernels
const int LoopSize_1 = VECTOR_LENGTH_1*NVECTORS_1;
const int LoopSize_2 = VECTOR_LENGTH_2*NVECTORS_2;
// Number of times a kernel should be run for each iteration
const uint32_t bufferRepetition_1 = NFRAMES_1*NPARTS;
const uint32_t bufferRepetition_2 = NFRAMES_2*NPARTS;
// Tiling Parameter for the input and output DDR
adf::tiling_parameters DDR_pattern1 = {
.buffer_dimension=ddr_size1,
.tiling_dimension={VECTOR_LENGTH_1*NVECTORS_1, NFRAMES_1,1},
.offset={0,0,0},
.tile_traversal={{.dimension=2, .stride=1, .wrap=NPARTS}}
};
adf::tiling_parameters DDR_pattern2 = {
.buffer_dimension=ddr_size2,
.tiling_dimension={VECTOR_LENGTH_2*NVECTORS_2, NFRAMES_2,1},
.offset={0,0,0},
.tile_traversal={{.dimension=2, .stride=1, .wrap=NPARTS}}
};
// Tiling Parameter for MEM Tiles
adf::tiling_parameters MEM_pattern1 = {
.buffer_dimension=shared_mem_size1,
.tiling_dimension={VECTOR_LENGTH_1,NVECTORS_1, 1},
.offset={0,0,0},
.tile_traversal={{.dimension=2, .stride=1, .wrap=NFRAMES_1}}
};
adf::tiling_parameters MEM_pattern2 = {
.buffer_dimension=shared_mem_size2,
.tiling_dimension={VECTOR_LENGTH_2,NVECTORS_2, 1},
.offset={0,0,0},
.tile_traversal={{.dimension=2, .stride=1, .wrap=NFRAMES_2}}
};
