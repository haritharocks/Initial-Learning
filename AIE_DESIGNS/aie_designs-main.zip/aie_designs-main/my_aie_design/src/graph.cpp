#include "graph.h"
#include <fstream>
#ifdef __AIESIM__
#include "../aie_runtime_control.cpp"
#endif

transfer_control g;

int main()
{
    const int ifm_size = 128;
    
 

    const int ofm_size = 128; 
    
    g.init();
//1
    uint32_t* ifmData = (uint32_t*)GMIO::malloc(ifm_size*sizeof(uint8_t));
    g.ddrin.setAddress(ifmData);
    std::ifstream ifm_ifs;
    ifm_ifs.open("data/ifm.txt");
    for (int i=0; i<ifm_size/4; i++)
        ifm_ifs >> std::hex >> ifmData[i];
    ifm_ifs.close();
   
    uint32_t* ofmData = (uint32_t*)GMIO::malloc(ofm_size*sizeof(uint8_t));
    g.ddrout.setAddress(ofmData);
	
    g.run(1);
    
#ifdef __AIESIM__
    executeRuntimeControl();
#endif
    
    g.end();
    
#ifndef __X86SIM__
    system("mkdir aiesimulator_output/data");
    std::ofstream ofs;
    ofs.open("aiesimulator_output/data/output1.txt", std::ofstream::out | std::ofstream::trunc);
#else
    system("mkdir x86simulator_output/data");
    std::ofstream ofs;
    ofs.open("x86simulator_output/data/output1.txt", std::ofstream::out | std::ofstream::trunc);
#endif

	for (int i=0; i<ofm_size/4; i++)
		ofs<<std::hex<<(uint32_t)ofmData[i]<<std::endl;
    ofs.close();
	GMIO::free(ifmData);
	GMIO::free(ofmData);
    return 0;
}
