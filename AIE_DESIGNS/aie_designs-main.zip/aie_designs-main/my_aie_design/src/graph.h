#pragma once

#include "adf.h"
#include "tiling_parameters.h"
#include "passthrough.h"

using namespace adf;

class transfer_control : public graph {
public:
    kernel K1,K2;
    external_buffer<uint32> ddrin,ddrout;
    shared_buffer<uint32> mtx1,mtx2,mtx3;
    transfer_control() {
        // kernels
        K1 = kernel::create(PassThrough);
        source(K1) = "src/passthrough.cpp";
        headers(K1) = {"src/passthrough.h"};
        runtime<ratio>(K1) = 0.9;
        repetition_count(K1) = bufferRepetition_1;
        K2 = kernel::create(PassThrough);
        source(K2) = "src/passthrough.cpp";
        headers(K2) = {"src/passthrough.h"};
        runtime<ratio>(K2) = 0.9;
        repetition_count(K2) = bufferRepetition_2;

        // External Buffers
        // Size, number of input ports, number of output ports
        ddrin = external_buffer<uint32>::create(ddr_size1, 0, 1);
        ddrout = external_buffer<uint32>::create(ddr_size2, 1, 0);

        // Shared Buffers
        // Size, number of input ports, number of output ports
        mtx1 = shared_buffer<uint32_t>::create(shared_mem_size1,1,1);
        repetition_count(mtx1) = NPARTS;
        mtx2 = shared_buffer<uint32_t>::create(shared_mem_size2,1,1);
        repetition_count(mtx2) = NPARTS;
        mtx3 = shared_buffer<uint32_t>::create(shared_mem_size2,1,1);
        repetition_count(mtx3) = NPARTS;

        // Shared buffers support ping-pong buffering
        num_buffers(mtx1) = 2;
        num_buffers(mtx2) = 2;
        num_buffers(mtx3) = 2;

        // Connect Input DDR to Input MEM Tile
        connect(ddrin.out[0], mtx1.in[0]);
        read_access(ddrin.out[0]) = DDR_pattern1;
        write_access(mtx1.in[0]) = MEM_pattern1;

        // Kernel 1 connection
        connect(mtx1.out[0], K1.in[0]);
        read_access(mtx1.out[0]) = MEM_pattern1;
        dimensions(K1.in[0]) = buffer_size1;
        connect(K1.out[0], mtx2.in[0]);
        dimensions(K1.out[0]) = buffer_size1;
        write_access(mtx2.in[0]) = MEM_pattern1;

        // Kernel 2 connection
        connect(mtx2.out[0], K2.in[0]);
        read_access(mtx2.out[0]) = MEM_pattern2;
        dimensions(K2.in[0]) = buffer_size2;
        connect(K2.out[0], mtx3.in[0]);
        dimensions(K2.out[0]) = buffer_size2;
        write_access(mtx3.in[0]) = MEM_pattern2;

        // Connect Output MEM Tile to Output DDR
        connect(mtx3.out[0], ddrout.in[0]);
        read_access(mtx3.out[0]) = MEM_pattern2;
        write_access(ddrout.in[0]) = DDR_pattern2;
    }
};
