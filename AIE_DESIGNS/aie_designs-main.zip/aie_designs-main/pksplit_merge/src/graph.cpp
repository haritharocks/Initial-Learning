#include "graph.h"

using namespace adf;


ExplicitPacketSwitching mygraph;

int main(void) { 
    adf::return_code ret;
    mygraph.init();
    ret=mygraph.run(1/*Number of iterations*/);
    if(ret!=adf::ok){
        printf("Run failed\n");
        return ret;
    }
    ret=mygraph.end();
    if(ret!=adf::ok){
        printf("End failed\n");
        return ret;
    }
    return 0;
}
