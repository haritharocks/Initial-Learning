#pragma once

#include "adf.h"
#include "kernel.h"

using namespace adf;

class ExplicitPacketSwitching: public adf::graph {
    private:
    adf:: kernel core[4];
    adf:: pktsplit<4> sp;
    adf:: pktmerge<4> mg;
    
    public:
    adf::input_plio in;
    adf::output_plio out;
    ExplicitPacketSwitching() {
        in=input_plio::create("Datain0", plio_32_bits, "data/input.txt");
        out=output_plio::create("Dataout0", plio_32_bits, "data/output.txt");
        sp = adf::pktsplit<4>::create();
        mg = adf::pktmerge<4>::create();
        for(int i=0 ; i< 4; i++){
            core[i] = adf::kernel::create(aie_core);
            source(core[i]) = "kernel.cc";
            runtime<ratio>(core[i]) = 0.9;
            adf::connect(sp.out[i], core[i].in[0]);
            adf::connect(core[i].out[0], mg.in[i]);
        }
        adf::connect(in.out[0], sp.in[0]);
        adf::connect(mg.out[0], out.in[0]);
    }
};
