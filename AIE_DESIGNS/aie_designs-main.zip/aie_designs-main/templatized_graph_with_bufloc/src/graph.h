#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;


template<uint32_t t_cols, uint32_t t_rows, uint32_t t_startcol=0, uint32_t t_startrow=0>
class template_graph : public adf::graph {
private:
    const uint32_t c_numcores = t_cols * t_rows;
    adf::kernel krnl[t_cols * t_rows];
    input_plio in;
    output_plio out;
public:

    template_graph() {
        for (int i = 0 ; i < t_cols; i++){
            for (int j = 0 ; j < t_rows; j++){
                int k = i*t_rows + j;
                krnl[k] = adf::kernel::create(simple);
                source(krnl[k]) = "kernels.cc";
                runtime<ratio>(krnl[k]) = 0.9;
                location<kernel>(krnl[k]) = tile(t_startcol+i, t_startrow+j);
                //location<buffer>(krnl[k].in[0]) ={ 
                //    address(t_startcol+i, t_startrow +j, 0x0),
                //    address(t_startcol+i, t_startrow+j,0x2000)
                //}; //double buffer location
                location<stack>(krnl[k]) = bank(t_startcol+i,t_startrow+j,2); //stack location
                location<buffer>(krnl[k].out[0]) = location<kernel>(krnl[k]); //relative buffer location

            }
        }
        in = input_plio::create(plio_32_bits, "data/input.txt");
        out = output_plio::create(plio_32_bits, "data/output.txt");
        connect(in.out[0], krnl[0].in[0]);
        for (int i = 0 ; i < c_numcores ; i++){
            if (i == c_numcores-1){
                connect(krnl[i].out[0], out.in[0]);
            }else{
                connect(krnl[i].out[0], krnl[i+1].in[0]);
            }
            dimensions(krnl[i].in[0])  = {128};
            dimensions(krnl[i].out[0]) = {128};
        }
    }
};
