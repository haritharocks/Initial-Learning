#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;

class SimpleGraph : public adf::graph {
private:
    adf::kernel first, second;
public:
    input_plio in1,in2,in3,in4;
    output_plio out1,out2;
public:
    SimpleGraph() {
        first = adf::kernel::create(mult_scalar);
        second = adf::kernel::create(mult_vec);

        source(first) = "kernels.cc";
        source(second) = "kernels.cc";

        runtime<ratio>(first) = 0.1;
        runtime<ratio>(second) = 0.1;

        in1  = input_plio::create(plio_32_bits, "data/input1.txt");
        in2  = input_plio::create(plio_32_bits, "data/input2.txt");
        in3  = input_plio::create(plio_32_bits, "data/input1.txt");
        in4  = input_plio::create(plio_32_bits, "data/input2.txt");
        out1 = output_plio::create(plio_32_bits, "data/output1.txt");
        out2 = output_plio::create(plio_32_bits, "data/output2.txt");
        connect(in1.out[0], first.in[0]);
        connect(in2.out[0], first.in[1]);
        connect(in3.out[0], second.in[0]);
        connect(in4.out[0], second.in[1]);
        connect(first.out[0], out1.in[0]);
        connect(second.out[0], out2.in[0]);
        dimensions(first.in[0])   = {NUM_SAMPLES};
        dimensions(first.in[1])   = {NUM_SAMPLES};
        dimensions(first.out[0])  = {NUM_SAMPLES};
        dimensions(second.in[0])  = {NUM_SAMPLES};
        dimensions(second.in[1])  = {NUM_SAMPLES};
        dimensions(second.out[0]) = {NUM_SAMPLES};
    }
};
