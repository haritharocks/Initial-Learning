#include <adf.h>
#include "kernels.h"
#include "aie_api/utils.hpp"
#define VEC 8
void mult_scalar(
    adf::input_buffer<int32> & __restrict in1,
    adf::input_buffer<int32> & __restrict in2,
    adf::output_buffer<int32> & __restrict out
    )
{
    printf("Running kernel\n");
    auto inItr1 = aie::begin(in1);
    auto inItr2 = aie::begin(in2);
    auto outItr = aie::begin(out);
    aie::tile tile=aie::tile::current();
    unsigned long long stime=tile.cycles();
    for (unsigned i=0; i<NUM_SAMPLES; i++) {
        auto a = *inItr1++;
        auto b = *inItr2++;
        int32 c = a*b;
        *outItr++ = c ;
        //printf("i=%d in1=%x in2=%x out=%x \n",i,a,b, c);
    }
    unsigned long long etime=tile.cycles();
    printf("%s: start cycle=%lld , end cycle=%lld total cycles=%lld\n",__FUNCTION__,stime,etime,etime-stime);
}
void mult_vec(
    adf::input_buffer<int32> & __restrict in1,
    adf::input_buffer<int32> & __restrict in2,
    adf::output_buffer<int32> & __restrict out
    )
{
    printf("Running Mult vec kernel\n");
    auto in1Itr = aie::begin_vector<VEC>(in1);
    auto in2Itr = aie::begin_vector<VEC>(in2);
    auto outItr = aie::begin_vector<VEC>(out);
    size_t loop_cnt = (NUM_SAMPLES -1)/ VEC + 1;
    aie::tile tile=aie::tile::current();
    unsigned long long stime=tile.cycles();
    for (unsigned i=0; i< loop_cnt; i++) chess_prepare_for_pipelining {
        auto va = *in1Itr++;
        auto vb = *in2Itr++;
        auto vt = aie::mul(va,vb);
        auto vout = vt.to_vector<int32>(0);
        //aie::print(va,false,"va=");
        //aie::print(vb,false," vb=");
        //aie::print(vout,true," vout=");
        *outItr++ = vt.to_vector<int32>(0);
    }
    unsigned long long etime=tile.cycles();
    printf("%s: start cycle=%lld , end cycle=%lld total cycles=%lld\n",__FUNCTION__,stime,etime,etime-stime);
}
