#ifndef FUNCTION_KERNELS_H
#define FUNCTION_KERNELS_H
#include "aie_api/aie.hpp"
#include "aie_api/aie_adf.hpp"
#define NUM_SAMPLES 512

void mult_scalar(
            adf::input_buffer<int32> & __restrict in1, 
            adf::input_buffer<int32> & __restrict in2, 
            adf::output_buffer<int32> & __restrict out
            );
void mult_vec(
            adf::input_buffer<int32> & __restrict in1, 
            adf::input_buffer<int32> & __restrict in2, 
            adf::output_buffer<int32> & __restrict out
            );
#endif
