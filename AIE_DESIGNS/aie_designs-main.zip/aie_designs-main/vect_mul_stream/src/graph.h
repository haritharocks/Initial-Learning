#pragma once

#include "adf.h"
#include "kernels.h"

using namespace adf;

class SimpleGraph : public adf::graph {
private:
    adf::kernel kmm2s,ks2mm, vmult;
public:
    input_plio in1,in2;
    output_plio out;
public:
    SimpleGraph() {
        kmm2s  = adf::kernel::create(mm2s);
        vmult = adf::kernel::create(mult_vec);
        ks2mm  = adf::kernel::create(s2mm);

        source(kmm2s) = "kernels.cc";
        source(vmult) = "kernels.cc";
        source(ks2mm) = "kernels.cc";

        runtime<ratio>(kmm2s) = 0.9;
        runtime<ratio>(vmult) = 0.9;
        runtime<ratio>(ks2mm) = 0.9;

        in1  = input_plio::create(plio_32_bits, "data/input1.txt");
        in2  = input_plio::create(plio_32_bits, "data/input2.txt");
        out = output_plio::create(plio_32_bits, "data/output.txt");
        
        connect(in1.out[0], kmm2s.in[0]);
        connect(in2.out[0], vmult.in[0]);
        adf::connect<adf::stream> net1 (kmm2s.out[0], vmult.in[1]);
        adf::connect<adf::stream> net3 (vmult.out[0], ks2mm.in[0]);
        connect(ks2mm.out[0], out.in[0]);

        dimensions(kmm2s.in[0])  = {NUM_SAMPLES};
        dimensions(vmult.in[0])  = {NUM_SAMPLES};
        dimensions(ks2mm.out[0]) = {NUM_SAMPLES};
    }
};
