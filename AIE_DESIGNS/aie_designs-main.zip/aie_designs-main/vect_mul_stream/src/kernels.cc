#include <adf.h>
#include "kernels.h"
#include "aie_api/utils.hpp"
#define VEC 8
void mm2s(
    adf::input_buffer<int32> & inbuf,
    output_stream_int32 *outstr
    )
{
    printf("Running %s kernel\n",__FUNCTION__);
    auto inItr = aie::begin_vector<VEC>(inbuf);
    size_t loop_cnt = (NUM_SAMPLES -1)/ VEC + 1;
    for (unsigned i=0; i< loop_cnt; i++) chess_prepare_for_pipelining {
        auto va = *inItr++;
        writeincr(outstr,va);
        aie::print(va,true,"va=");
    }
}
void mult_vec(
    adf::input_buffer<int32> & inbuf,
    input_stream_int32  *instr,
    output_stream_int32 *outstr
    )
{
    printf("Running %s kernel\n",__FUNCTION__);
    size_t loop_cnt = (NUM_SAMPLES -1)/ VEC + 1;
    auto inItr = aie::begin_vector<VEC>(inbuf);
    for (unsigned i=0; i< loop_cnt; i++) chess_prepare_for_pipelining {
        auto va = *inItr++;
        auto vb = readincr_v<VEC>(instr);
        auto vt = aie::mul(va,vb);
        auto vout = vt.to_vector<int32>(0);
        writeincr(outstr, vout);
        aie::print(va,false,"va=");
        aie::print(vb,false," vb=");
        aie::print(vout,true," vout=");
    }
}
void s2mm(
    input_stream_int32  *instr,
    adf::output_buffer<int32> & __restrict out
    )
{
    printf("Running %s kernel\n",__FUNCTION__);
    auto outItr = aie::begin_vector<VEC>(out);
    size_t loop_cnt = (NUM_SAMPLES -1)/ VEC + 1;
    for (unsigned i=0; i< loop_cnt; i++) chess_prepare_for_pipelining {
        auto vout = readincr_v<VEC>(instr);
        *outItr++ = vout;
        aie::print(vout,true," vout=");
    }
}
