#ifndef FUNCTION_KERNELS_H
#define FUNCTION_KERNELS_H
#include "aie_api/aie.hpp"
#include "aie_api/aie_adf.hpp"
#define NUM_SAMPLES 128

void mm2s(
            adf::input_buffer<int32> & in1, 
            output_stream_int32 *out
            );
void mult_vec(
            adf::input_buffer<int32> & inBuf, 
            input_stream_int32  *inStr, 
            output_stream_int32 *out
            );
void s2mm(
            input_stream_int32  *in, 
            adf::output_buffer<int32> & __restrict out
            );
#endif
